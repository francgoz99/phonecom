<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title><?php echo e(request()->input('item')); ?> | <?php echo e(config('app.name')); ?></title>

	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="css/listing.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>		
	<main>
		<div class="top_banner">
			<div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.3)">
				<div class="container">
					<div class="breadcrumbs">
						<ul>
							<li><a href="<?php echo e(route('landing-page')); ?>">Home</a></li>
							<li><?php echo e(request()->input('item')); ?></li>
						</ul>
					</div>
					<h1><?php echo e($products->total()); ?> search result(s) for <?php echo e(request()->input('item')); ?></h1>
				</div>
			</div>
			<img src="<?php echo e(asset('')); ?>img/banner1.jpg" class="img-fluid" alt="" style="width: 100%;">
		</div>
		<!-- /top_banner -->
			<div id="stick_here"></div>		
			<div class="toolbox elemento_stick">
				<div class="container">
				<ul class="clearfix">
					<li>
							<a  href="<?php echo e(route('shop.index', ['category' => request()->category, 'subCategory' => request()->subCategory, 'sort' => 'low_high'])); ?>">Low to High</a>
					</li>
					<li>
                			<a  href="<?php echo e(route('shop.index', ['category' => request()->category, 'subCategory' => request()->subCategory, 'sort' => 'high_low'])); ?>">High to Low</a>
							
					</li>
					
				</ul>
				</div>
			</div>
			<!-- /toolbox -->
			
			<div class="container margin_30">
			
			<div class="row">
				
				<!-- /col -->
				<div class="col-lg-12">
					<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="row small-gutters">
						<?php if($products->count() > 0): ?>
              			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-6 col-md-3 card">
							<div class="grid_item">
								<?php echo $product->quantity < setting('site.stock_threshold') ? '<span class="ribbon off">Only '.$product->quantity.' left</span>' : ''; ?>

								<figure>
									<a href="<?php echo e(route('shop.show', $product->slug)); ?>">
										<img class="img-fluid lazy" src="<?php echo e(productImage($product->image)); ?>" data-src="<?php echo e(productImage($product->image)); ?>" alt="">
									</a>
									
								</figure>
								<a href="<?php echo e(route('shop.show', $product->slug)); ?>">
									<h3><?php echo e($product->name); ?></h3>
								</a>
								<div class="price_box">
									<span class="new_price">&#8358;<?php echo e(number_format( $product->price)); ?></span>
									<span class="old_price">&#8358;<?php echo e(number_format( slash($product->price) )); ?></span>
								</div>
								<ul>
									
									<li>
										<form action="<?php echo e(route('compare.store')); ?>" method="POST">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
					                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
					                        <input type="hidden" name="price" value="<?php echo e(totalcash($product->price, $product->profit)); ?>">
					                          <div class="form-group">
					                            <button type="submit" class="btn btn-info" ><i class="ti-control-shuffle"></i></button>
					                          </div>
					                      </form>
									</li>
									
									<li>
										<form action="<?php echo e(route('cart.store')); ?>" method="POST">
				                            <?php echo csrf_field(); ?>
				                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
				                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
				                            <input type="hidden" name="price" value="<?php echo e(totalcash($product->price, $product->profit)); ?>">
				                              <div class="d-flex justify-content-between align-items-center">
				                                <button type="submit" class="btn btn-warning" data-toggle="tooltip" data-placement="left" title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></button>
				                              </div>
				                          </form>
									</li>
								</ul>
								</ul>
							</div>
							<!-- /grid_item -->
						</div>
						<!-- /col -->
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            <?php else: ?>
			              <p>No product Found</p>
			            <?php endif; ?>  		
						
					</div>
					<!-- /row -->
					<div class="pagination__wrapper">
						<ul class="pagination">
							<?php echo e($products->appends(request()->input())->onEachSide(1)->links()); ?>

						</ul>
					</div>
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->			
				
		</div>
		<!-- /container -->
	</main>
	<!-- /main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="js/sticky_sidebar.min.js"></script>
	<script src="js/specific_listing.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/search-results.blade.php ENDPATH**/ ?>