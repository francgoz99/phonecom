<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="<?php echo e($product->keywords); ?>">
    <meta name="description" content="<?php echo e($product->name); ?> is in <?php echo e($subName); ?> category and it's features are <?php echo $product->details; ?>">
    <meta property="og:image" content="<?php echo e(productImage($product->image)); ?>">
    <meta name="author" content="Ansonika">
    <title><?php echo e($product->name); ?> :- <?php echo str_limit($product->details, 30); ?> | <?php echo e(config('app.name')); ?></title>
	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('')); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="<?php echo e(asset('')); ?>css/product_page.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(asset('')); ?>css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
	<main>
	    <div class="container margin_30">
	        <div class="countdown_inner">-20% This offer ends in <div data-countdown="2019/05/15" class="countdown"></div>
	        </div>
	        <div class="row">
	            <div class="col-md-6">
	                <div class="all">
	                    <div class="slider">
	                        <div class="owl-carousel owl-theme main">
	                            <div style="background-image: url(<?php echo e(productImage($product->image)); ?>);" class="item-box"></div>
	                            <?php if($product->images): ?>                    
                      				<?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            		<div style="background-image: url(<?php echo e(productImage($image)); ?>);" class="item-box"></div>
                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        		<?php endif; ?>
	                        </div>
	                        <div class="left nonl"><i class="ti-angle-left"></i></div>
	                        <div class="right"><i class="ti-angle-right"></i></div>
	                    </div>
	                    <div class="slider-two">
	                        <div class="owl-carousel owl-theme thumbs">
	                            <div style="background-image: url(<?php echo e(productImage($product->image)); ?>);" class="item active"></div>
	                            <?php if($product->images): ?>                    
                      				<?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            		<div style="background-image: url(<?php echo e(productImage($image)); ?>);" class="item"></div>
                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        		<?php endif; ?>
	                        </div>
	                        <div class="left-t nonl-t"></div>
	                        <div class="right-t"></div>
	                    </div>
	                </div>
	            </div>
	            <div class="col-md-6">
	                <div class="breadcrumbs">
	                    <ul>
	                        <li><a href="<?php echo e(route('landing-page')); ?>">Home</a></li>
	                        <li><a href="#"><?php echo e($subName); ?></a></li>
	                        <li><?php echo e($product->name); ?></li>
	                    </ul>
	                </div>
	                <!-- /page_header -->
	                <div class="prod_info">
	                    <h1><?php echo e($product->name); ?></h1>
	                    <span class="rating">
	                    	<?php if($reviews->count() > 0): ?>
	                    	<?php 

	                    		$total = $reviews->sum('rating') / $reviews->count();
	                    	?>
		                    	<?php for($i = 0; $i < $total; $i++): ?>
	                        		<i class="icon-star voted"></i>
	                    		<?php endfor; ?>
		                    	<em><?php echo e($reviews->count()); ?> reviews</em></span>
	                    	<?php else: ?>
	                    		<em>0 reviews</em></span>
	                    	<?php endif; ?>
	                    <p>
	                    	<small><?php echo $stockLevel; ?></small>
		                    	<br>
		                    
		                </p>
	                    
	                    <div class="row">
	                        <div class="col-lg-12 col-md-12">
	                            <div class="price_main"><span class="new_price">&#8358;<?php echo e(number_format(totalcash($product->price))); ?></span> <span class="old_price">&#8358;<?php echo e(number_format(slash($product->price))); ?></span></div>
	                        </div>
	                        <hr>
	                        <div class="col-lg-6 col-md-6">
	                        	 <?php if($product->quantity > 0): ?>
					                <form action="<?php echo e(route('cart.store')); ?>" method="POST">
					                  <?php echo e(csrf_field()); ?>

					                  <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
					                  <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
					                  <input type="hidden" name="price" value="<?php echo e(totalcash($product->price)); ?>">
					                    <div class="btn_add_to_cart">
					                      <button type="submit" class="btn_1">ADD TO CART</button>
					                    </div>
					                </form>
					              <?php endif; ?> 
	                        </div>
	                        <div class="col-lg-6 col-md-6">
			                      <a class="btn btn-block" style="background-color: #ff6600; color:white;" href="https://wa.me/2347031382795?text=Hello Mr. Testech, I will like to order for this item <?php echo e($product->name); ?> - <?php echo str_limit($product->details, 30); ?> as seen on <?php echo e(url()->current()); ?>"><i data-feather="whatsapp" class="fa fa-whatsapp"></i> Order on Whatsapp</a>
			                  </div>
	                    </div>
	                </div>
	                <!-- /prod_info -->
	                <div class="product_actions">
	                    <ul>
	                        
	                        <li>
	                        	<form action="<?php echo e(route('compare.store')); ?>" method="POST">
			                        <?php echo csrf_field(); ?>
			                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
			                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
			                        <input type="hidden" name="price" value="<?php echo e(totalcash($product->price, $product->profit)); ?>">
			                          <div class="form-group">
			                            <button type="submit" class="btn btn-block" ><i class="ti-control-shuffle"></i><span>Add to Compare</span></button>
			                          </div>
			                      </form>
	                        </li>
	                    </ul>
		              <div class="d-flex align-items-center">
		                <span class="text-muted">Share</span>
		                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Facebook" target="_blank"><i data-feather="facebook" class="fa fa-facebook"></i></a>
		                <a href="https://twitter.com/intent/tweet?text=Check out <?php echo e($product->name.' '.str_limit($product->details, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Twitter"><i data-feather="twitter" class="fa fa-twitter" target="_blank"></i></a>
		                <a href="https://wa.me/?text=Check out <?php echo e($product->name.' '.str_limit($product->details, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Whatsapp" target="_blank"><i data-feather="whatsapp" class="fa fa-whatsapp"></i></a>
		              </div>
	                </div>
	                <!-- /product_actions -->
	            </div>
	        </div>
	        <!-- /row -->
	    </div>
	    <!-- /container -->
	    
	    <div class="tabs_product">
	        <div class="container">
	            <ul class="nav nav-tabs" role="tablist">
	                <li class="nav-item">
	                    <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Description</a>
	                </li>
	                <li class="nav-item">
	                    <a id="tab-B" href="#pane-B" class="nav-link" data-toggle="tab" role="tab">Reviews</a>
	                </li>
	            </ul>
	        </div>
	    </div>
	    <!-- /tabs_product -->
	    <div class="tab_content_wrapper">
	        <div class="container">
	            <div class="tab-content" role="tablist">
	                <div id="pane-A" class="card tab-pane fade active show" role="tabpanel" aria-labelledby="tab-A">
	                    <div class="card-header" role="tab" id="heading-A">
	                        <h5 class="mb-0">
	                            <a class="collapsed" data-toggle="collapse" href="#collapse-A" aria-expanded="false" aria-controls="collapse-A">
	                                Description
	                            </a>
	                        </h5>
	                    </div>
	                    <div id="collapse-A" class="collapse" role="tabpanel" aria-labelledby="heading-A">
	                        <div class="card-body">
	                            <div class="row justify-content-between">
	                                <div class="col-lg-12">
	                                    <h3>Details</h3>
	                                    <?php echo $product->description; ?>

	                                </div>
	                                
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <!-- /TAB A -->
	                <div id="pane-B" class="card tab-pane fade" role="tabpanel" aria-labelledby="tab-B">
	                    <div class="card-header" role="tab" id="heading-B">
	                        <h5 class="mb-0">
	                            <a class="collapsed" data-toggle="collapse" href="#collapse-B" aria-expanded="false" aria-controls="collapse-B">
	                                Reviews
	                            </a>
	                        </h5>
	                    </div>
	                    <div id="collapse-B" class="collapse" role="tabpanel" aria-labelledby="heading-B">
	                        <div class="card-body">
	                            <div class="row justify-content-between">
	                            	<?php if($reviews->count() > 0): ?>
              						<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <div class="col-lg-6">
	                                    <div class="review_content">
	                                        <div class="clearfix add_bottom_10">
	                                            <span class="rating">
	                                            	<?php for($i = 0; $i < $review->rating; $i++): ?>
	                                            		<i class="icon-star"></i>
                                            		<?php endfor; ?>
	                                            	<em><?php echo e($review->rating); ?>/5.0</em>
	                                            </span>
	                                            <em>Published <?php echo e($review->created_at->format('d M, Y')); ?></em>
	                                        </div>
	                                        <h4>"<?php echo e($review->user_name); ?>"</h4>
	                                        <p><?php echo e($review->review); ?></p>
	                                    </div>
	                                </div>
	                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						              <?php else: ?>
						                <h6>No Review yet!</h6>
						              <?php endif; ?>
	                                
	                            </div>
	                            <!-- /row -->
	                        </div>
	                        <!-- /card-body -->
	                    </div>
	                </div>
	                <!-- /tab B -->
	            </div>
	            <!-- /tab-content -->
	        </div>
	        <!-- /container -->
	    </div>
	    <!-- /tab_content_wrapper -->

	    <div class="container margin_60_35">
	        <div class="main_title">
	            <h2>Related</h2>
	            <span><?php echo $subName; ?></span>
	        </div>
	        <div class="owl-carousel owl-theme products_carousel">
	        	<?php $__currentLoopData = $relaProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relaProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <div class="item" style="border: 1px solid black; border-radius: 10px;">
	                <div class="grid_item">
	                    <span class="ribbon new"><?php echo $product->quantity < setting('site.stock_threshold') ? '<div class="badge badge-danger badge-pill">Only '.$product->quantity.' left in stock</div>' : ''; ?></span>
	                    <figure>
	                        <a href="<?php echo e(route('shop.show', $relaProduct->slug)); ?>">
	                            <img class="owl-lazy" src="<?php echo e(productImage($relaProduct->image)); ?>" data-src="<?php echo e(productImage($relaProduct->image)); ?>" alt="<?php echo e($relaProduct->name); ?> :- <?php echo str_limit($relaProduct->details, 30); ?>">
	                        </a>
	                    </figure>
	                    <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i></div>
	                    <a href="<?php echo e(route('shop.show', $relaProduct->slug)); ?>">
	                        <h3><?php echo e($relaProduct->name); ?></h3>
	                    </a>
	                    <div class="price_box">
	                        <span class="new_price">&#8358;<?php echo e(number_format( $relaProduct->price)); ?></span>
	                    </div>
	                    
	                </div>
	                <!-- /grid_item -->
	            </div>
	            <!-- /item -->
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>
	        <!-- /products_carousel -->
	    </div>
	    <!-- /container -->

	    <div class="feat">
			<div class="container">
				<ul>
					<li>
						<div class="box">
							<i class="ti-gift"></i>
							<div class="justify-content-center">
								<h3>Free Shipping</h3>
								<p>For all oders over $99</p>
							</div>
						</div>
					</li>
					<li>
						<div class="box">
							<i class="ti-wallet"></i>
							<div class="justify-content-center">
								<h3>Secure Payment</h3>
								<p>100% secure payment</p>
							</div>
						</div>
					</li>
					<li>
						<div class="box">
							<i class="ti-headphone-alt"></i>
							<div class="justify-content-center">
								<h3>24/7 Support</h3>
								<p>Online top support</p>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<!--/feat-->

	</main>
	<!-- /main -->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
 	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(asset('')); ?>js/common_scripts.min.js"></script>
    <script src="<?php echo e(asset('')); ?>js/main.js"></script>
  
    <!-- SPECIFIC SCRIPTS -->
    <script  src="<?php echo e(asset('')); ?>js/carousel_with_thumbs.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/detail.blade.php ENDPATH**/ ?>