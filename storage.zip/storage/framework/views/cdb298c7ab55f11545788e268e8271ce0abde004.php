<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Order Details | <?php echo e(config('app.name')); ?></title>

	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('')); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="<?php echo e(asset('')); ?>css/error_track.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(asset('')); ?>css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	
	<main class="bg_gray">
		<div class="container">
			<h4>Order Details</h4>
			<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="card user-card">
            <div class="card-body">
              <div class="media">
                <?php echo $__env->make('inc.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <hr>
              <h3><u>#TT<?php echo e($order->id); ?></u></h3>

              <ul class="nav nav-pills main-nav-pills" role="tablist">
                <li class="nav-item">
                  <a class="nav-link text-success" href="javascript:void(0)"><i class="fa fa-refresh"></i> PROCESSING</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link disabled" href="javascript:void(0)"><i class="fa fa-long-arrow-right"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link text-success" href="javascript:void(0)"><i class="fa fa-paper-plane"></i> SENDING</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link disabled" href="javascript:void(0)"><i class="fa fa-long-arrow-right"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link text-<?php echo e($order->shipped == 1 ? 'success' : 'muted'); ?>" href="javascript:void(0)"><i class="fa fa-gift"></i> DELIVERED</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link disabled" href="javascript:void(0)"><i class="fa fa-long-arrow-right"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link text-<?php echo e($order->shipped == 1 ? 'success' : 'muted'); ?>" href="javascript:void(0)"><i class="fa fa-check-circle"></i> FINISHED</a>
                </li>
              </ul>

              <table class="table table-cart">
                <tbody>
                  <?php $price = 0; ?>
                  <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tr>
                    <td hidden></td>
                    <td>
                      <a href="<?php echo e(route('shop.show',$product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" width="50" height="50" alt="Product image" alt="<?php echo e($product->name); ?>"></a>
                      <button class="btn btn-sm btn-outline-warning rounded">Remove</button>
                    </td>
                    <td>
                      <h6><a href="<?php echo e(route('shop.show',$product->slug)); ?>" class="text-body"><?php echo e($product->name); ?></a></h6>
                      <h6 class="text-muted">&#8358;<?php echo e(number_format( totalcash($product->price, $product->profit) )); ?></h6>
                      
                      
                    </td>
                    <td>
                      Qty:
                      <?php $__currentLoopData = $order->order_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xyz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($product->id == $xyz['product_id']): ?>
                                <?php echo e($xyz['quantity']); ?>

                                <span class="price">&#8358;<?php echo e(number_format($xyz['quantity'] * totalcash($product->price, $product->profit))); ?></span>
                                
                            <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </td>
                  </tr>
                  
                  <?php $price += totalcash($product->price, $product->profit) ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
              <div class="text-right">
                <table class="table table-borderless table-sm mb-5">
                    <tbody>

                      <tr>
                        <td>Subtotal</td>
                        <td style="width:150px" class="roboto-condensed bold">&#8358;<?php echo e(number_format($order->billing_subtotal)); ?></td>
                      </tr>

                      <tr>
                        <td>Discount(<?php echo e($order->billing_discount_code); ?>)</td>
                        <td class="roboto-condensed bold">  
                          &#8358;<?php echo e(number_format($order->billing_discount)); ?>

                       </td>
                      </tr>                      

                      <tr>
                        <td>Shipping Fee</td>
                        <td class="roboto-condensed bold">
                          &#8358;<?php echo e(number_format($order->delivery_fee)); ?>

                       </td>
                      </tr>

                      <tr>
                        <td class="bold">TOTAL</td>
                        <td class="roboto-condensed bold text-success h5">&#8358;<?php echo e(number_format($order->billing_subtotal + $order->delivery_fee)); ?></td>
                      </tr>
                    </tbody>
                  </table>
              </div>

              <div class="row">
                <div class="col-lg-6">
                  <h5 class="bold"><u>Shipping Address :</u></h5>
                  <strong><?php echo e(auth()->user()->name.' '.auth()->user()->lname); ?></strong><br/>
                  <?php echo e(auth()->user()->email); ?><br/>
                  <?php echo e(auth()->user()->phone); ?><br/>
                  <?php echo e(auth()->user()->address); ?><br/>
                </div>
                
              </div>
              <div class="d-flex justify-content-between mt-3">
                <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-primary btn-sm rounded-pill"><i class="fa fa-long-arrow-left"></i> Back</a>
                <button type="button" class="btn btn-primary btn-sm rounded-pill"><i class="fa fa-print"></i> Print</button>
              </div>

            </div>
          </div>
        </div>
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(asset('')); ?>js/common_scripts.min.js"></script>
    <script src="<?php echo e(asset('')); ?>js/main.js"></script>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/account-order-detail.blade.php ENDPATH**/ ?>