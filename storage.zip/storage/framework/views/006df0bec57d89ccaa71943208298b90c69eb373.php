              <?php if(auth()->guard()->check()): ?>
                
                <div class="media-body ml-3 pt-4">
                  <h4><?php echo e($user->name." ".$user->lname); ?></h4>
                  <div class="small text-muted">Joined <?php echo e($user->created_at); ?></div>
                  
                  
                </div>
              </div>
              <hr>
              <ul class="nav nav-pills">
                <li class="nav-item" style="margin: 5px;">
                  <a class="nav-link btn btn-primary " href="<?php echo e(route('users.edit')); ?>">Profile</a>
                </li>
                <li class="nav-item" style="margin: 5px;">
                  <a class="nav-link btn btn-primary " href="<?php echo e(route('orders.index')); ?>">Orders</a>
                </li>
                <li class="nav-item" style="margin: 5px;">
                  <a class="nav-link btn btn-primary " href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>
                </li>
                 
              </ul>
                <?php endif; ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/inc/account.blade.php ENDPATH**/ ?>