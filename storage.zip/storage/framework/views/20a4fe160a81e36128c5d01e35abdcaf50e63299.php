<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="<?php echo str_limit($post->meta_keywords, 60); ?>">
    <meta name="description" content="<?php echo str_limit($post->body, 150); ?>">
    <meta name="author" content="Ansonika">
    <title><?php echo $post->title; ?> | <?php echo e(config('app.name')); ?></title>
	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(asset('')); ?>css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>css/style.css" rel="stylesheet">
	
	<!-- SPECIFIC CSS -->
    <link href="<?php echo e(asset('')); ?>css/blog.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(asset('')); ?>css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>	
	<main class="bg_gray">
		<div class="container margin_30">
			<div class="page_header">
				<div class="breadcrumbs">
					<ul>
						<li><a href="<?php echo e(route('landing-page')); ?>">Home</a></li>
						<li><?php echo $post->title; ?></li>
					</ul>
				</div>
			</div>
			<!-- /page_header -->
			<div class="row">
				<div class="col-lg-9">
					<div class="singlepost">
						<figure><img alt="<?php echo $post->title; ?>" class="img-fluid" src="<?php echo e(productImage($post->image)); ?>"></figure>
						<h1><?php echo $post->title; ?></h1>
						<div class="postmeta">
							<ul>
								<li><a href="#"><i class="ti-folder"></i> Category</a></li>
								<li><i class="ti-calendar"></i> <?php echo e($post->created_at->format('d M, Y')); ?></li>
								<li><a href="#"><i class="ti-user"></i> Admin</a></li>
								<li><a href="#"><i class="ti-comment"></i> (<?php echo e($comments->count()); ?>) Comments</a></li>
							</ul>
						</div>
						<!-- /post meta -->
						<div class="post-content">
							<div class="dropcaps">
								<?php echo $post->body; ?>

							</div>

							
						</div>
						<!-- /post -->
					</div>
					<!-- /single-post -->

					<div id="comments">
						<h5>Comments</h5>
						<ul>
							<?php if($comments->count() > 0): ?>
              					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<div class="avatar">
											<a href="#"><img src="img/avatar3.jpg" alt="">
											</a>
										</div>

										<div class="comment_right clearfix">
											<div class="comment_info">
												By <a href="#"><?php echo e($comment->name); ?></a><span>|</span><?php echo e($comment->created_at); ?><span>|</span><a href="#"><i class="icon-reply"></i></a>
											</div>
											<p>
												<?php echo e($comment->body); ?>

											</p>
										</div>
									</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			              <?php else: ?>
			              <p>No Comment yet!</p>
			              <?php endif; ?>
						</ul>
					</div>

					<hr>

					<h5>Login to Leave a comment</h5>
					<?php if(auth()->guard()->check()): ?>
					<form action="<?php echo e(route('blog.store')); ?>" method="POST">
                    	<?php echo csrf_field(); ?>
						<div class="form-group">
							<textarea class="form-control" name="body" id="comments2" rows="6" placeholder="Comment"></textarea>
						</div>
						<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
						<div class="form-group">
							<button type="submit" id="submit2" class="btn_1 add_bottom_15">Submit</button>
						</div>
					</form>
					<?php endif; ?>
					
				</div>
				<!-- /col -->

				<aside class="col-lg-3">
					
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>POPULAR POST</h4>
						</div>
						<ul class="comments-list">
							<?php if($populars->count() > 0): ?>
	               				 <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<div class="alignleft">
											<a href="<?php echo e(route('blog.show', $popular->slug)); ?>"><img src="<?php echo e(productImage($popular->image)); ?>" alt="<?php echo $popular->title; ?>"></a>
										</div>
										<small><?php echo e($popular->created_at->format('d M, Y')); ?></small>
										<h3><a href="<?php echo e(route('blog.show', $popular->slug)); ?>" title=""><?php echo $popular->title; ?></a></h3>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                <?php else: ?>
			                <p>No Popular Post this week</p>
			                <?php endif; ?>
							
						</ul>
					</div>
					
					
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(asset('')); ?>js/common_scripts.min.js"></script>
    <script src="<?php echo e(asset('')); ?>js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/blog-single.blade.php ENDPATH**/ ?>