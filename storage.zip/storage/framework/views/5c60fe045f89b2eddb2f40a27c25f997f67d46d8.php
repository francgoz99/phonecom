<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>My Profile | <?php echo e(config('app.name')); ?></title>

	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="css/error_track.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	
	<main class="bg_gray">
		<div class="container">
			<h4>My Profile</h4>
			<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="card user-card">
            <div class="card-body">
              <div class="media">
               <?php echo $__env->make('inc.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <hr>
              <form action="<?php echo e(route('users.update')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('patch')); ?>

                <div class="form-row">
                  <div class="form-group col-sm-6">
                    <label for="profileFirstName">First Name</label>
                    <input name="name" type="text" class="form-control" id="profileFirstName" value="<?php echo e(old('name', $user->name)); ?>">
                  </div>
                  <div class="form-group col-sm-6">
                    <label for="profileLastName">Last Name</label>
                    <input name="lname" type="text" class="form-control" id="profileLastName" value="<?php echo e(old('name', $user->lname)); ?>">
                  </div>
                  <div class="form-group col-sm-6">
                    <label for="profileEmail">Email address</label>
                    <input type="email" name="email" class="form-control" id="profileEmail" value="<?php echo e(old('email', $user->email)); ?>">
                  </div>
                  <div class="form-group col-sm-6">
                    <label for="profilePhone">Phone Number</label>
                    <input name="phone" type="number" class="form-control" id="profilePhone" value="<?php echo e(old('phone', $user->phone)); ?>">
                  </div>
                  <div class="form-group col-sm-6">
                    <label for="profilePassword">Password</label>
                    <input type="password" name="password" class="form-control" id="profilePassword">
                    <p><i>Leave password blank to keep current password</i></p>
                  </div>
                  <div class="form-group col-sm-6">
                    <label for="profileConfirmPassword">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control" id="profileConfirmPassword">
                  </div>
                  <div class="form-group col-12">
                  <div class="form-group col-sm-12">
                    <label for="profilePhone">Address</label>
                    <input name="address" type="text" class="form-control" id="profileAddress" value="<?php echo e(old('phone', $user->address)); ?>">
                  </div>
                    <button type="submit" class="btn btn-success btn-block">SAVE</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/account-profile.blade.php ENDPATH**/ ?>