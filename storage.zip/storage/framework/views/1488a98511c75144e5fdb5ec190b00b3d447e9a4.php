<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Compare | <?php echo e(config('app.name')); ?></title>

	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="css/error_track.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	
	<main class="bg_gray">
		<div class="container">
			<h4>Compare</h4>
			<?php if(Cart::instance('compare')->count() > 0): ?>
		          <div class="table-responsive">
		            <table class="table table-bordered text-center table-wishlist">
		              <thead>
		                <tr>
		                  
		                  <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                  <th>
		                    <p><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->image)); ?>" width="75" height="75" alt="<?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?>"></a></p>
		                    <p><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>" class="text-body"><?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?></a></p>
		                    <div class="btn-group btn-group-sm" role="group">
		                      <form action="<?php echo e(route('compare.switchToCart', $item->rowId)); ?>" method="POST">
		                          <?php echo e(csrf_field()); ?>

		                      <button type="submit" class="btn btn-outline-info">Add to cart</button>
		                      </form>
		                    </div>
		                  </th>
		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
		                  
		                  
		                </tr>
		              </thead>
		              <tbody>
		                <tr>

		                <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                  <td>
		                    <strong>Price:</strong>
		                    <div>&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></div>
		                  </td>      
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
		                  
		                </tr>
		                
		                <tr>
		                  <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                  <td>                    
		                    <div class="btn-group btn-group-sm" role="group">
		                       <form action="<?php echo e(route('compare.destroy', $item->rowId)); ?>" method="POST">
		                          <?php echo e(csrf_field()); ?>

		                          <?php echo e(method_field('DELETE')); ?>

		                      <button type="submit" class="btn btn-outline-info">Remove</button>
		                      </form>
		                    </div>
		                  </td>
		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
		                </tr>
		              </tbody>
		            </table>
		          </div>
		<?php endif; ?>
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/compare.blade.php ENDPATH**/ ?>