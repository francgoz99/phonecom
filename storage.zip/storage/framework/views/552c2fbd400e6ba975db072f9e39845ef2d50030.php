<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Blog | <?php echo e(config('app.name')); ?></title>
	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	
	<!-- SPECIFIC CSS -->
    <link href="css/blog.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	
	<main class="bg_gray">
		<div class="container margin_30">
			<div class="page_header">
				<div class="breadcrumbs">
					<ul>
						<li><a href="<?php echo e(route('landing-page')); ?>">Home</a></li>
						<li>Blog</li>
					</ul>
				</div>
				<h1><?php echo e(config('app.name')); ?> &amp; News</h1>
			</div>
			<!-- /page_header -->
			<div class="row">
				<div class="col-md-9">
					
					<!-- /widget -->
					<div class="row">
						<?php if($posts->count() > 0): ?>
	          				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-6">
								<article class="blog">
									<figure>
										<a href="<?php echo e(route('blog.show', $post->slug)); ?>"><img src="<?php echo e(productImage($post->image)); ?>" alt="">
											<div class="preview"><span>Read more</span></div>
										</a>
									</figure>
									<div class="post_info">
										<small><?php echo $post->created_at->format('d M, Y'); ?></small>
										<h2><a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo $post->title; ?></a></h2>
										
										
									</div>
								</article>
								<!-- /article -->
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					          <?php else: ?>
					          <p>No Post yet!</p>
					          <?php endif; ?>
					</div>
					

					<div class="pagination__wrapper no_border add_bottom_30">
						<ul class="pagination">
							<?php echo e($posts->appends(request()->input())->links()); ?>

						</ul>
					</div>
					<!-- /pagination -->

				</div>
				<!-- /col -->

				<aside class="col-md-3">
					
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Latest Post</h4>
						</div>
						<ul class="comments-list">
							<?php if($populars->count() > 0): ?>
                				<?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<div class="alignleft">
											<a href="<?php echo e(route('blog.show', $popular->slug)); ?>"><img src="img/blog-5.jpg" alt="<?php echo $popular->title; ?>"></a>
										</div>
										<small><?php echo $popular->created_at->format('d M, Y'); ?></small>
										<h3><a href="<?php echo e(route('blog.show', $popular->slug)); ?>" title=""><?php echo $popular->title; ?></a></h3>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                <?php else: ?>
			                <p>No Popular Post this week</p>
			                <?php endif; ?>
						</ul>
					</div>
					
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/blog-list.blade.php ENDPATH**/ ?>