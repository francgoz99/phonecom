<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title><?php echo e(strtoupper(config('app.name'))); ?></title>
	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="css/home_1.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
		
	<main>
		<div id="carousel-home">
			<div class="owl-carousel owl-theme">
				<?php if($banners->count() > 0): ?>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="owl-slide cover" style="background-image: url(<?php echo productImage($banner->image); ?>);">
					<div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.5)">
						<div class="container">
							<div class="row justify-content-center justify-content-md-end">
								<div class="col-lg-6 static">
									<div class="slide-text text-right white">
										<h2 class="owl-slide-animated owl-slide-title">Attack Air<br>Max 720 Sage Low</h2>
										<p class="owl-slide-animated owl-slide-subtitle">
											Limited items available at this price
										</p>
										<div class="owl-slide-animated owl-slide-cta"><a class="btn_1" href="<?php echo e($banner->routes); ?>" role="button">Shop Now</a></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              <?php endif; ?>
				
			</div>
			<div id="icon_drag_mobile"></div>
		</div>
		<!--/carousel-->

		<ul id="banners_grid" class="clearfix">
			<li>
				<a href="#0" class="img_container">
					<img src="img/banners_cat_placeholder.jpg" data-src="img/banner_1.jpg" alt="" class="lazy">
					<div class="short_info opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.5)">
						<h3>Men's Collection</h3>
						<div><span class="btn_1">Shop Now</span></div>
					</div>
				</a>
			</li>
			<li>
				<a href="#0" class="img_container">
					<img src="img/banners_cat_placeholder.jpg" data-src="img/banner_2.jpg" alt="" class="lazy">
					<div class="short_info opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.5)">
						<h3>Womens's Collection</h3>
						<div><span class="btn_1">Shop Now</span></div>
					</div>
				</a>
			</li>
			<li>
				<a href="#0" class="img_container">
					<img src="img/banners_cat_placeholder.jpg" data-src="img/banner_3.jpg" alt="" class="lazy">
					<div class="short_info opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.5)">
						<h3>Kids's Collection</h3>
						<div><span class="btn_1">Shop Now</span></div>
					</div>
				</a>
			</li>
		</ul>
		<!--/banners_grid -->
		
		<div class="container margin_60_35">
			<div class="main_title">
				<h2>Top Selling</h2>
				<span>Products</span>
				
			</div>
			<div class="row small-gutters">
				<?php if($latests->count() > 0): ?>
          			<?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-6 col-md-3 card">
						<div class="grid_item">
							<?php echo $latest->quantity < setting('site.stock_threshold') ? '<span class="ribbon off">Only '.$latest->quantity.' left</span>' : ''; ?>

							<figure>
								<a href="<?php echo e(route('shop.show', $latest->slug)); ?>">
									<img class="img-fluid lazy" src="<?php echo e(productImage($latest->image)); ?>" data-src="<?php echo e(productImage($latest->image)); ?>" alt="">
								</a>
								
							</figure>
							<a href="<?php echo e(route('shop.show', $latest->slug)); ?>">
								<h3><?php echo e($latest->name); ?></h3>
							</a>
							<div class="price_box">
								<span class="new_price">&#8358;<?php echo e(number_format( $latest->price)); ?></span>
								<span class="old_price">&#8358;<?php echo e(number_format( slash($latest->price) )); ?></span>
							</div>
							<ul>
								
								<li>
									<form action="<?php echo e(route('compare.store')); ?>" method="POST">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="id" value="<?php echo e($latest->id); ?>">
				                        <input type="hidden" name="name" value="<?php echo e($latest->name); ?>">
				                        <input type="hidden" name="price" value="<?php echo e(totalcash($latest->price, $latest->profit)); ?>">
				                          <div class="form-group">
				                            <button type="submit" class="btn btn-info" ><i class="ti-control-shuffle"></i></button>
				                          </div>
				                      </form>
								</li>
								
								<li>
									<form action="<?php echo e(route('cart.store')); ?>" method="POST">
			                            <?php echo csrf_field(); ?>
			                            <input type="hidden" name="id" value="<?php echo e($latest->id); ?>">
			                            <input type="hidden" name="name" value="<?php echo e($latest->name); ?>">
			                            <input type="hidden" name="price" value="<?php echo e(totalcash($latest->price, $latest->profit)); ?>">
			                              <div class="d-flex justify-content-between align-items-center">
			                                <button type="submit" class="btn btn-warning" data-toggle="tooltip" data-placement="left" title="Add to cart"><i class="ti-shopping-cart"></i><span>Add to cart</span></button>
			                              </div>
			                          </form>
								</li>
							</ul>
						</div>
						<!-- /grid_item -->
					</div>
					<!-- /col -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            <?php else: ?>
		              <p>No product Found</p>
		            <?php endif; ?> 
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->

		<div class="featured lazy" data-bg="url(img/cable.png)">
			<div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.5)">
				<div class="container margin_60">
					<div class="row justify-content-center justify-content-md-start">
						<div class="col-lg-6 wow" data-wow-offset="150">
							<h3>Armor<br>Air Color 720</h3>
							<p>Lightweight cushioning and durable support with a Phylon midsole</p>
							<div class="feat_text_block">
								<div class="price_box">
									<span class="new_price">$90.00</span>
									<span class="old_price">$170.00</span>
								</div>
								<a class="btn_1" href="listing-grid-1-full.html" role="button">Shop Now</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /featured -->

		<div class="container margin_60_35">
			<div class="main_title">
				<h2>Featured</h2>
				<span>Products</span>
				
			</div>
			<div class="owl-carousel owl-theme products_carousel">
				<?php if($boosteds->count() > 0): ?>
				<?php $__currentLoopData = $boosteds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boosted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <div class="item card" >
	                <div class="grid_item">
	                    <?php echo $boosted->quantity < setting('site.stock_threshold') ? '<span class="ribbon off">Only '.$boosted->quantity.' left</span>' : ''; ?>

	                    <figure>
	                        <a href="<?php echo e(route('shop.show', $boosted->slug)); ?>">
	                            <img class="owl-lazy" src="<?php echo e(productImage($boosted->image)); ?>" data-src="<?php echo e(productImage($boosted->image)); ?>" alt="<?php echo e($boosted->name); ?> :- <?php echo str_limit($boosted->details, 30); ?>">
	                        </a>
	                    </figure>
	                    <div class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i></div>
	                    <a href="<?php echo e(route('shop.show', $boosted->slug)); ?>">
	                        <h3><?php echo e($boosted->name); ?></h3>
	                    </a>
	                    <div class="price_box">
	                        <span class="new_price">&#8358;<?php echo e(number_format( $boosted->price)); ?></span>
	                    </div>
	                    
	                </div>
	                <!-- /grid_item -->
	            </div>
	            <!-- /item -->
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            <?php endif; ?>
				
				<!-- /item -->
			</div>
			<!-- /products_carousel -->
		</div>
		<!-- /container -->
		
		<div class="bg_gray">
			<div class="container margin_30">
				<div id="brands" class="owl-carousel owl-theme">
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_1.png" alt="" class="owl-lazy"></a>
					</div><!-- /item -->
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_2.png" alt="" class="owl-lazy"></a>
					</div><!-- /item -->
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_3.png" alt="" class="owl-lazy"></a>
					</div><!-- /item -->
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_4.png" alt="" class="owl-lazy"></a>
					</div><!-- /item -->
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_5.png" alt="" class="owl-lazy"></a>
					</div><!-- /item -->
					<div class="item">
						<a href="#0"><img src="img/brands/placeholder_brands.png" data-src="img/brands/logo_6.png" alt="" class="owl-lazy"></a>
					</div><!-- /item --> 
				</div><!-- /carousel -->
			</div><!-- /container -->
		</div>
		<!-- /bg_gray -->

		<div class="container margin_60_35">
			<div class="main_title">
				<h2>Latest News</h2>
				<span>Blog</span>
				
			</div>
			<div class="row">
				<?php if($posts->count() > 0): ?>
	          	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-6">
					<a class="box_news" href="<?php echo e(route('blog.show', $post->slug)); ?>">
						<figure>
							<img src="<?php echo e(productImage($post->image)); ?>" data-src="<?php echo e(productImage($post->image)); ?>" alt="<?php echo $post->title; ?>" width="400" height="266" class="lazy">
							<figcaption><strong>28</strong>Dec</figcaption>
						</figure>
						<ul>
							<li>by Admin</li>
							<li><?php echo $post->created_at->format('d M, Y'); ?></li>
						</ul>
						<h4><?php echo $post->title; ?></h4>
						<p><?php echo strip_tags(str_limit($post->body, $limit = 100, $end = '...')); ?></p>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		          <?php else: ?>
		          <p>No Post yet!</p>
		          <?php endif; ?>
				<!-- /box_news -->
				
				
				
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!-- /main -->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="js/carousel-home.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/landing-page.blade.php ENDPATH**/ ?>