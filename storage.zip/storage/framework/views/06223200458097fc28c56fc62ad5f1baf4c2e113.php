<!DOCTYPE html>
<html lang="en">

<script src="https://kit.fontawesome.com/dfbe4c7cae.js" crossorigin="anonymous"></script>
<?php echo $__env->yieldContent('head'); ?>

<body>
	
	<div id="page">
	
	<header class="version_1">
		<div class="layer"></div><!-- Mobile menu overlay mask -->
		<div class="main_header">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 d-lg-flex align-items-center">
						<div id="logo">
							<a href="<?php echo e(route('landing-page')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="100" height="35"></a>
						</div>
					</div>
					<nav class="col-xl-6 col-lg-7">
						<a class="open_close" href="javascript:void(0);">
							<div class="hamburger hamburger--spin">
								<div class="hamburger-box">
									<div class="hamburger-inner"></div>
								</div>
							</div>
						</a>
						<!-- Mobile menu button -->
						<div class="main-menu">
							<div id="header_menu">
								<a href="<?php echo e(route('landing-page')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="100" height="35"></a>
								<a href="#" class="open_close" id="close_in"><i class="ti-close"></i></a>
							</div>
							<ul>
								<li>
									<a href="<?php echo e(route('landing-page')); ?>">Home</a>
								</li>
								<li>
									<a href="<?php echo e(route('about')); ?>">About Us</a>
								</li>
								<li>
									<a href="<?php echo e(route('blog.index')); ?>">Blog</a>
								</li>
								<li>
									<a href="<?php echo e(route('faq')); ?>">FAQ</a>
								</li>
								<li>
									<a href="<?php echo e(route('contact')); ?>">Contact Us</a>
								</li>
								
							</ul>
						</div>
						<!--/main-menu -->
					</nav>
					<div class="col-xl-3 col-lg-2 d-lg-flex align-items-center justify-content-end text-right">
						<a class="phone_top" href="tel://9438843343"><strong><span>Need Help?</span>+94 423-23-221</strong></a>
					</div>
				</div>
				<!-- /row -->
			</div>
		</div>
		<!-- /main_header -->

		<div class="main_nav inner">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 col-md-3">
						<nav class="categories">
							<ul class="clearfix">
								<li><span>
										<a href="#">
											<span class="hamburger hamburger--spin">
												<span class="hamburger-box">
													<span class="hamburger-inner"></span>
												</span>
											</span>
											Categories
										</a>
									</span>
									<div id="menu">
										<ul>
											<?php $i = 0; ?>
								              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								              <?php $i++;?>
											<li><span class="<?php echo e(request()->category == $category->slug ? 'active' : ''); ?>"><a href="#0"><i class="fa fa-<?php echo e($category->icon); ?> fa-lg"></i> &nbsp;<?php echo e($category->name); ?></a></span>
												<ul>
													<?php $__currentLoopData = $allSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      									<?php if($category->id == $allSubCategory->category_id): ?>
															<li><a href="<?php echo e(route('shop.index', ['subCategory' => $allSubCategory->name])); ?>"><i class="fa fa-certificate "></i> &nbsp;<?php echo e($allSubCategory->name); ?></a></li>
														<?php endif; ?>
                    								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

											
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-xl-6 col-lg-7 col-md-6 d-none d-md-block">
						<div class="custom-search-input">
							<form action="<?php echo e(route('search')); ?>" method="GET" >
								<?php echo csrf_field(); ?>
						          <input type="text" name="item" value="<?php echo e(request()->input('item')); ?>" class="form-control" placeholder="Search over 10.000 products" aria-label="Search ...">
						          <button type="submit"><i class="header-icon_search_custom"></i></button>			        
						      </form>
						</div>
					</div>
					<div class="col-xl-3 col-lg-2 col-md-3">
						<ul class="top_tools">
							<li>
								<div class="dropdown dropdown-cart">
									<a href="<?php echo e(route('cart.index')); ?>" class="cart_bt">
										<strong>
										<?php if(Cart::instance('default')->count() > 0): ?>
							              <?php echo e(Cart::instance('default')->count()); ?>

						              	<?php else: ?>
						              		0
							            <?php endif; ?>  
										</strong>
									</a>
									<div class="dropdown-menu">
										<ul>
											<?php if(Cart::instance('default')->count() > 0): ?>
            								<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<a href="<?php echo e(route('shop.show', $item->model->slug)); ?>">
													<figure><img src="<?php echo e(productImage($item->model->image)); ?>" data-src="<?php echo e(productImage($item->model->image)); ?>" alt="" width="50" height="50" class="lazy"></figure>
													<strong><span><?php echo e($item->qty); ?> x <?php echo e($item->model->name); ?></span>&#8358;<?php echo e(number_format($item->model->price)); ?></strong>
												</a>
												<a href="#0" class="action"></a>
												<form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
								                      <?php echo csrf_field(); ?>
								                      <?php echo e(method_field('DELETE')); ?>

								                      <button type="submit" class="close" aria-label="Close"><i class="ti-trash"></i></button>
								                  </form>
											</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            								<?php endif; ?>
										</ul>
										<div class="total_drop">
											<div class="clearfix"><strong>Total</strong><span>&#8358;<?php echo e(session()->has('coupon') ? number_format(session()->get('newTotal')) : number_format(Cart::total())); ?></span></div>
											<a href="<?php echo e(route('cart.index')); ?>" class="btn_1 outline">View Cart</a><a href="<?php echo e(route('checkout.index')); ?>" class="btn_1">Checkout</a>
										</div>
									</div>
								</div>
								<!-- /dropdown-cart-->
							</li>
							<li>
								<a href="<?php echo e(route('wishlist.index')); ?>" class="wishlist"><span>Wishlist</span></a>
							</li>
							<li>
								<div class="dropdown dropdown-access">
									<a href="<?php echo e(route('users.edit')); ?>" class="access_link"><span>Account</span></a>
									<div class="dropdown-menu">
										<?php if(auth()->guard()->guest()): ?>
											<a href="/login" class="btn_1">Sign In or Sign Up</a>
										<?php else: ?>
											<a href="<?php echo e(route('users.edit')); ?>" class="btn_1">Dashboard</a>
										<?php endif; ?>
										<ul>
											
											<li>
												<a href="<?php echo e(route('users.edit')); ?>"><i class="ti-user"></i>My Profile</a>
											</li>
											<li>
												<a href="<?php echo e(route('faq')); ?>"><i class="ti-help-alt"></i>Help and Faq</a>
											</li>
											<?php if(auth()->guard()->check()): ?>
											<li>
												<a href="<?php echo e(route('orders.index')); ?>"><i class="ti-package"></i>My Orders</a>
											</li>
											<li>
												<a href="<?php echo e(route('wishlist.index')); ?>"><i class="ti-heart"></i>Wishlist (<?php echo e(Cart::instance('wishlist')->count()); ?>)</a>
											</li>
											<li>
												<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();             document.getElementById('logout-form').submit();"><i class="fa fa-sign-out-alt"></i>Logout</a>
											</li>
											<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								              <?php echo csrf_field(); ?>
								          </form>
								          <?php endif; ?>
										</ul>
									</div>
								</div>
								<!-- /dropdown-access-->
							</li>
							<li>
								<a href="javascript:void(0);" class="btn_search_mob"><span>Search</span></a>
							</li>
							<li>
								<a href="#menu" class="btn_cat_mob">
									<div class="hamburger hamburger--spin" id="hamburger">
										<div class="hamburger-box">
											<div class="hamburger-inner"></div>
										</div>
									</div>
									Categories
								</a>
							</li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<div class="search_mob_wp">
				<input type="text" class="form-control" placeholder="Search over 10.000 products">
				<input type="submit" class="btn_1 full-width" value="Search">
			</div>
			<!-- /search_mobile -->
		</div>
		<!-- /main_nav -->
	</header>
	<!-- /header -->
	
<?php echo $__env->yieldContent('main-content'); ?>
	
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<h3 data-target="#collapse_1">Quick Links</h3>
					<div class="collapse dont-collapse-sm links" id="collapse_1">
						<ul>
							<li><a href="<?php echo e(route('about')); ?>">About us</a></li>
							<li><a href="<?php echo e(route('faq')); ?>">Faq</a></li>
							<?php if(auth()->guard()->check()): ?>
							<li><a href="<?php echo e(route('users.edit')); ?>">My account</a></li>
							<?php else: ?>
							<li><a href="/login">Login</a></li>
							<?php endif; ?>
							<li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
							<li><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
							<li><a href="<?php echo e(route('policy')); ?>">Privacy Policy</a></li>
							<li><a href="<?php echo e(route('tandc')); ?>">Terms and Conditions</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3 data-target="#collapse_2">Categories</h3>
					<div class="collapse dont-collapse-sm links" id="collapse_2">
						<ul>
							<?php $i = 0; ?>
				              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				              <?php $i++;?>
							<li><a href="#"><?php echo e($category->name); ?></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
						<h3 data-target="#collapse_3">Contacts</h3>
					<div class="collapse dont-collapse-sm contacts" id="collapse_3">
						<ul>
							<li><i class="ti-home"></i>97845 Baker st. 567<br>Los Angeles - US</li>
							<li><i class="ti-headphone-alt"></i>+94 423-23-221</li>
							<li><i class="ti-email"></i><a href="#0">info@allaia.com</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
						<h3 data-target="#collapse_4">Keep in touch</h3>
					<div class="collapse dont-collapse-sm" id="collapse_4">
						<div id="newsletter">
						    <div class="form-group">
						        <input type="email" name="email_newsletter" id="email_newsletter" class="form-control" placeholder="Your email">
						        <button type="submit" id="submit-newsletter"><i class="ti-angle-double-right"></i></button>
						    </div>
						</div>
						<div class="follow_us">
							<h5>Follow Us</h5>
							<ul>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/twitter_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/facebook_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/instagram_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/youtube_icon.svg" alt="" class="lazy"></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- /row-->
			<hr>
			<div class="row add_bottom_25">
				<div class="col-lg-6">
					<ul class="footer-selector clearfix">
						<li>
							<div class="styled-select lang-selector">
								<select>
									<option value="English" selected>English</option>
									<option value="French">French</option>
									<option value="Spanish">Spanish</option>
									<option value="Russian">Russian</option>
								</select>
							</div>
						</li>
						<li>
							<div class="styled-select currency-selector">
								<select>
									<option value="US Dollars" selected>US Dollars</option>
									<option value="Euro">Euro</option>
								</select>
							</div>
						</li>
						<li><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/cards_all.svg" alt="" width="198" height="30" class="lazy"></li>
					</ul>
				</div>
				<div class="col-lg-6">
					<ul class="additional_links">
						<li><a href="#0">Terms and conditions</a></li>
						<li><a href="#0">Privacy</a></li>
						<li><span>© <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?></span></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!--/footer-->
	</div>
	<!-- page -->
	
	<div id="toTop"></div><!-- Back to top button -->
	
	<?php echo $__env->yieldContent('script'); ?>
		
</body>
</html><?php /**PATH C:\wamp64\Laravel\testech\resources\views/layouts/app.blade.php ENDPATH**/ ?>