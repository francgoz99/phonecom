<?php $__env->startSection('head'); ?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Wishlist | <?php echo e(config('app.name')); ?></title>

	
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="css/error_track.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	
	<main class="bg_gray">
		<div class="container">
			<h4>Wishlist</h4>
			 <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="card user-card">
            <div class="card-body">
              <div class="media">
                <?php echo $__env->make('inc.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <hr>
              <?php if(Cart::instance('wishlist')->count()): ?>
              <table class="table table-cart">
                <tbody>
                  
                  <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>                      
                      
                    </td>
                    <td>
                      <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->image)); ?>" width="50" height="50" alt="<?php echo e($item->model->name); ?> - <?php echo $item->model->details; ?>"></a>         
                      <form action="<?php echo e(route('wishlist.destroy', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                          <button type="submit" class="btn btn-sm btn-outline-warning rounded">Remove</button>
                      </form>
                    </td>
                    <td>
                      <h6><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>" class="text-body"><?php echo e($item->model->name); ?> - <?php echo $item->model->details; ?></a></h6>
                      <h6 class="text-muted">&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></h6>
                      
                        <?php echo getStockLevel($item->model->quantity); ?>

                      
                    </td>
                    <td>
                      <form action="<?php echo e(route('wishlist.switchToCart', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-info btn-sm">Move to cart</button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
                  
                </tbody>
              </table>
              <?php endif; ?>
            </div>
          </div>
      </div>
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('script'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/main.js"></script>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\testech\resources\views/account-wishlist.blade.php ENDPATH**/ ?>